#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int arr[]={42, 77, 3, 8, 69, 86, 60, 99, 50, 76, 15, 14, 41, 87, 45, 61, 16, 50, 20, 5, 13, 33, 62, 70, 70, 77, 28, 85, 82, 26, 28, 32, 56, 22, 21, 48, 38, 42, 98, 20, 44, 66, 21, 55, 98, 17, 20, 93, 99, 54, 21, 43, 80, 99, 64, 98, 55, 3, 95, 16, 56, 62, 42, 83, 72, 23, 71, 61, 90, 14, 33, 45, 84, 25, 24, 96, 74, 2, 1, 92, 25, 33, 36, 6, 26, 14, 37, 33, 100, 3, 30, 1, 31, 31, 86, 92, 61, 86, 81, 38};
void func1(char* paramstr,int paramint){
    assert(paramint == 24);
    for (int i=0; (i < paramint); ++i) {
        paramstr[i] ^= arr[i % sizeof((arr))] ^ (0x1337);
    };
};

int func2(FILE* fileparam){
    if ((fseek(fileparam,(0x000 + 0x200 + 0x800 - 0xA00),(0x004 + 0x202 + 0x802 - 0xA06)) < (0x000 + 0x200 + 0x800 - 0xA00)) & !!(fseek(fileparam,(0x000 + 0x200 + 0x800 - 0xA00),(0x004 + 0x202 + 0x802 - 0xA06)) < (0x000 + 0x200 + 0x800 - 0xA00))){
        fclose(fileparam);
        return -1;
    };
    int a=ftell(fileparam);
    rewind(fileparam);
    return a;
};

int main(int arg1int,const char * arg2str[]){
    char* str1;
    char* str2=NULL;
    FILE* file;
    if ((arg1int ^ 0x002)){
        printf("Not enough arguments provided!");
        exit(-1);
    };
    file = fopen(arg2str[1],"r");
    if (file == NULL){
        perror("Error opening file: No such file or directory");
        return -1;
    };
    int maybesize=func2(file);
    str2 = (char* )malloc(maybesize + 1);
    if (str2 == NULL){
        perror("Memory allocation error");
        fclose(file);
        return -1;
    };
    fgets(str2,maybesize,file);
    fclose(file);
    func1(str2,maybesize);
    file = fopen("output", "wb");
    if (file == NULL){
        perror("Error opening file");
        return -1;
    };
    fwrite(str2,maybesize,sizeof(char),file);
    fclose(file);
    free(str2);
    return 0;
};
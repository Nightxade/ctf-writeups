#include <stdio.h>

int main() {
   printf("Hi mom!\n");
   return 0;
}
